"""
Código 2:
Uso de variables, importación de módulos
y la función print para imprimir resultados.
"""

# TODO Tarea 1:
# Importar el módulo math para usar el valor de pi
# (Usa: import math)
import math

# Declarar una variable para el radio del círculo (usa un nombre descriptivo)
radio_circulo = 5

# TODO Tarea 2:
# Calcular el área del círculo usando la fórmula:
# área = pi * radio^2
# Usa math.pi y radio_circulo ** 2
area = math.pi * radio_circulo ** 2

# Imprimir el resultado
print("El área del círculo es:", area)

# Salida esperada:
# El área del círculo es: 78.53981633974483

