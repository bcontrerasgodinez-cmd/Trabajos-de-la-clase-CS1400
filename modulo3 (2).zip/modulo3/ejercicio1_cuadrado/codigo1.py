"""
Código1:
Un programa para encontrar el cuadrado de un número.
"""

# Definir una variable llamada 'num' y asignarle el valor 4
num = 4

# TODO Tarea 1:
# Crea una variable llamada 'cuadrado' y asígnale el valor del cuadrado de 'num'.
cuadrado = num ** 2

# Mostrar el resultado
print(cuadrado)

# Salida esperada:
# 16